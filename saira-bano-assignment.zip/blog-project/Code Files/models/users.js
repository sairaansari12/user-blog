const DataTypes = require('sequelize');
const shortid = require('shortid');

const userObject = {
    id: {
      allowNull: false,
      primaryKey: true,
      type: DataTypes.STRING,
      defaultValue: () => shortid.generate()
    },
    username: { type: DataTypes.STRING, allowNull: false,unique:true ,validate: {
        is: /^[A-Za-z0-9]*$/,

      },
    
      unique: {
        args: true,
        msg: 'Username is already taken!'
    }
    },
    password: { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, allowNull:false, unique:true,validate: {
        isEmail: true 
      }}
  };

  const userSchema = SqlzConnection.define('users', userObject, {
    freezeTableName: true
  });
  
  export default userSchema;