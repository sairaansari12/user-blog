const DataTypes = require('sequelize');
const shortid = require('shortid');

const modelObject = {
    id: {
      allowNull: false,
      primaryKey: true,
      type: DataTypes.STRING,
      defaultValue: () => shortid.generate()
    },
    comment: { type: DataTypes.TEXT, allowNull: false,
      validate: {
        containsUrl: (value) => { 
        
          var urlRE= new RegExp("([a-zA-Z0-9]+://)?([a-zA-Z0-9_]+:[a-zA-Z0-9_]+@)?([a-zA-Z0-9.-]+\\.[A-Za-z]{2,4})(:[0-9]+)?([^ ])+");
         
          const result= value.match(urlRE)
          if(result && result.index)
          throw new Error('URL not allowed in comments');

        }
      }
    },
    userId: { type: DataTypes.STRING, allowNull: false},
    postId: { type: DataTypes.STRING, allowNull: false},
    createdAt: { type: DataTypes.DATE, allowNull: true, defaultValue: new Date()
    },

    
  };

  const commentSchema = SqlzConnection.define('comments', modelObject, {
    freezeTableName: true
  });
  
  export default commentSchema;