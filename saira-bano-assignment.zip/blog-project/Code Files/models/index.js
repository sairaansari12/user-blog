import userSchema from './users';
import postSchema from './posts';
import commentSchema from './comments';


postSchema.belongsTo(userSchema, {
    foreignKey: 'userId',
    targetId: 'id'
  });

  commentSchema.belongsTo(postSchema, {
    foreignKey: 'postId',
    targetId: 'id'
  });
  
postSchema.hasMany(commentSchema, {
    foreignKey: 'postId',
    sourceKey: 'id',
    onDelete: 'CASCADE',
    hooks: true
  });

  export { postSchema, commentSchema, userSchema}