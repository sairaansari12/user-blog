const DataTypes = require('sequelize');
const shortid = require('shortid');

const modelObject = {
    id: {
      allowNull: false,
      primaryKey: true,
      type: DataTypes.STRING,
      defaultValue: () => shortid.generate()
    },
    title: { type: DataTypes.STRING, allowNull: false,unique:true ,
        unique: {
            args: true,
            msg: 'Title is already exists!'
        },
        validate: {
        is: /^[A-Za-z ]*$/
      }},
    description: { type: DataTypes.TEXT, allowNull: false },
    userId: { type: DataTypes.STRING, allowNull: false},
    createdAt: { type: DataTypes.DATE, allowNull: true, defaultValue: new Date()
    },

    
  };

  const postSchema = SqlzConnection.define('posts', modelObject, {
    freezeTableName: true
  });
  
  export default postSchema;