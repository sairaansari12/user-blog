const routes = require("express").Router();

import userCtrl from "./controllers/user.js";
import postsCtrl from "./controllers/posts.js";
import commentsCtrl from "./controllers/comments.js";

import { error } from "./helpers/responseHelper";

routes.use("/users", userCtrl);
routes.use("/comment", commentsCtrl);
routes.use("/post", postsCtrl);



routes.use((req, res) => {
  return error(res, "Please again check the url,This path is not specified", 404);
});

module.exports=routes;