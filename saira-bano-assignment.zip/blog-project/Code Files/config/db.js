console.log(process.env.DB_DIALECT)

module.exports = db = {
  username: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
  setting: {
    host: process.env.DB_HOST,
    dialect: process.env.DB_DIALECT,
    pool: {
      max: 1000,
      min: 0,
      idle: 10000,
      acquire: 10000
    },
    dialectOptions: {
      supportBigNumbers: true,
      bigNumberStrings: true,
      multipleStatements: true
    },
    replication: {
      read: { host: process.env.DB_HOST, username: process.env.DB_USERNAME, password: process.env.DB_PASSWORD },
      write: { host: process.env.DB_HOST, username: process.env.DB_USERNAME, password: process.env.DB_PASSWORD }
    },
    logging: false
  }
}