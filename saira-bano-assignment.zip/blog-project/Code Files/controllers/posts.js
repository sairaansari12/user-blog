const router = require("express").Router();
import { post, exportValidation } from "../helpers/responseHelper";
import { checkParameterMissing } from "../helpers/common";
import { postSchema, userSchema, commentSchema } from "../models";

router.post("/create",async (req, res) => {
  try {
    const params = req.body;


    let responseNull = checkParameterMissing([params.title.trim(), params.description, params.userId]);
    if (responseNull) return post(res, appstrings.required_field, null, 400);

    const result = await postSchema.create({ userId: params.userId, title: params.title.trim(), description: params.description })

    if (result)
      return post(res, appstrings.success, result);

    else
      return post(res, appstrings.error, null, 400);

  } catch (e) {
    console.log(e.message)
    exportValidation(res,e && e.message?e.message:appstrings.error,e,400)
  }
});

router.get('/list',async (req, res, next) => {

  var params = req.query


  var page = 1
  var limit = 20

  if (params.page) page = params.page
  if (params.category) category = params.category

  if (params.limit)
    limit = Number(params.limit)
  var offset = (page - 1) * limit



  try {

    var result = await postSchema.findAndCountAll({
      where: { userId: params.userId },
      order: [['createdAt', 'DESC']],
      distinct: true,
      offset: offset, limit: limit,

    })

    return post(res, appstrings.success, result);

  }
  catch (e) {
    console.log(e)
    exportValidation(res,e.message,e,400)
  }

});

router.get('/detail/:postId', async (req, res, next) => {
  try {
    var params = req.params
    var postId = params.postId
    let responseNull = checkParameterMissing([postId])
    if (responseNull) return post(res, appstrings.required_field, null, 400);

    //Get All Categories
    var findData = await postSchema.findOne({
      where: { id: postId },
      include: [{ model: userSchema, required: true },
      { model: commentSchema, }
      ]

    })




    if (findData)
      return post(res, appstrings.success, findData);

    else return post(res, appstrings.no_record, null, 204);


  }
  catch (e) {
    exportValidation(res,e.message,e,400)
  }


});

export default router;
