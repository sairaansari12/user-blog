const router = require("express").Router();
import { post, exportValidation } from "../helpers/responseHelper";
const commonMethods = require("../helpers/common");
const {commentSchema } = require("../models");

router.post("/postComment",async (req, res) => {
  try {
    const params = req.body;


    let responseNull = commonMethods.checkParameterMissing([params.comment, params.postId, params.userId]);
    if (responseNull) return post(res, appstrings.required_field, null, 400);

    const result = await commentSchema.create({ userId: params.userId, comment: params.comment, postId: params.postId })

    if (result)
      return post(res, appstrings.success, result);

    else
      return post(res, appstrings.error, null, 400);

  } catch (e) {
    exportValidation(res,e.message,e,400)


  }
});


export default router;