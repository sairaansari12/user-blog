const router = require("express").Router();
import { post, exportValidation } from "../helpers/responseHelper";
import { checkParameterMissing } from "../helpers/common";
import { userSchema } from "../models";
const hashPassword = require('../helpers/hashPassword');

router.post("/create",async (req, res) => {
  try {
    const params = req.body;


    let responseNull = checkParameterMissing([params.username, params.email, params.password]);
    if (responseNull) return post(res, appstrings.required_field, null, 400);

     const pswd = await hashPassword.generatePass(params.password);

    const result = await userSchema.create({ username: params.username, email: params.email, password: pswd })

    if (result)
      return post(res, appstrings.success, result);

    else
      return post(res, result.message, null, 400);

  } catch (e) {
    exportValidation(res,e.message,e,400)

   
}
});



export default router;
