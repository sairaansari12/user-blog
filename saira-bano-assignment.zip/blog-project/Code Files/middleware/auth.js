
import jwt from 'jsonwebtoken';


//use AWS COGNITO for authentication
function userAuth (req, res, next) {
    const token = req.headers.authorization;
    const userId = req.headers.userid;
    if (!token || !userId) {
      const error = new Error('Unauthenticated');
      error.statusCode = 401;
      return next(error);
    }

    request(
      {
url:'cognito_URL'    ,
    json: true
      },
      (error, response, body) => {
        if (error) {
          return next(error);
        }
        if (body) {
          const pems = {};
          const { keys } = body;
          for (let i = 0; i < keys.length; i += 1) {
            // Convert each key to PEM
            const key_id = keys[i].kid;
            const modulus = keys[i].n;
            const exponent = keys[i].e;
            const key_type = keys[i].kty;
            const jwk = { kty: key_type, n: modulus, e: exponent };
            const pem = jwkToPem(jwk);
            pems[key_id] = pem;
          }

          // validate the token
          const decodedJwt = jwt.decode(token, { complete: true });
          if (!decodedJwt) {
            const error = new Error('Unauthenticated');
            error.statusCode = 401;
            return next(error);
          }

          const { kid } = decodedJwt.header;
          const pem = pems[kid];
          if (!pem) {
            const error = new Error('Unauthenticated');
            error.statusCode = 401;
            return next(error);
          }
          jwt.verify(token, pem, function (err, payload) {
            if (err) {
              console.log(err);
              //   const error = new Error('Unauthenticated');
              //   if (err.message === 'jwt expired') {
              //     error.message = 'jwt expired';
              //   }
              err.statusCode = 401;
              return next(err);
            }
            req.jwtPayload = payload;
            req.userId = userId;
            return next();
          });
        }
      }
    );
     next()
  }



export {userAuth}