require('dotenv-flow').config()
import { createServer } from "http";
import Sequelize from "sequelize";
import express from "express";
global.appstrings = require("./language.json")["en"];
const bodyParser = require("body-parser");
const app = express();
const server = createServer(app);
const PORT = process.env.APP_PORT || 9070;
const db = require("./config/db");

global.checkAuth =require('./middleware/auth').userAuth


app.use(
  bodyParser.json({
    limit: "50mb",
  })
);


// //database connection
// global.SqlzConnection = new Sequelize(db.database, null, null, db.setting);
// global.SqlzConnection = new Sequelize(db.database,db.username, db.password,db.setting);
global.SqlzConnection= new Sequelize(db.database, db.username, db.password, db.setting);

try {
  SqlzConnection.sync();
   } catch (error) {
    console.log(error);
  }


  const routes = require("./routes");

app.use("/api", routes);



server.listen(PORT, () => {
  console.log(`Server Listening on PORT ${PORT}`);
});

