# HotelBookingApp

### Prerequisites to run the project:
1. Install Nodejs (Currently using : Node 16.20)


### Steps to Run the project
1. Open Visual Studio code or any Code Editor
2. Open Project Folder -> Code Files
3. Run Command : npm install
4. Run Command: npm run dev

//Now server will start listening on the port 9070
Run api on postman by using following details :


### API Details
 Follow the collection : 

 https://www.postman.com/saira-345678/workspace/demo/collection/7150918-f6c659f8-325b-45b4-b835-35e3ff8bd011?action=share&creator=7150918








   
